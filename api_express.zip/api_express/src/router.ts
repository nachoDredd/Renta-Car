import { Router } from "express"
import { borrarArriendo, crearArriendo, editarArriendo, getArriendoById, getArriendos } from "./handlers/arriendos"
import { editarUsuario, getUsuarios } from "./handlers/usuarios"

const router = Router()

//endpoints arriendos
router.get("/arriendos", getArriendos)
router.get("/arriendos/:id", getArriendoById)
router.post("/arriendos", crearArriendo)
router.put("/arriendos/:id", editarArriendo)
router.delete("/arriendos/:id", borrarArriendo)

//endpoints usuarios
router.get("/usuarios", getUsuarios)
router.put("/usuarios/:email", editarUsuario)


export default router
