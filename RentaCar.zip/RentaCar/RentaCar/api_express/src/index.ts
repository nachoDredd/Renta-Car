import server from "./server";

server.listen(3000, () => {
    console.log('inicio API Express')
})