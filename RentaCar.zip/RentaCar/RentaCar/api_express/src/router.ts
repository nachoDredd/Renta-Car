import { Router } from "express"
import { borrarArriendo, crearArriendo, editarArriendo, getArriendoById, getArriendos, getArriendosTerminados } from "./handlers/arriendos"
import { crearUsuario, editarUsuario, getUsuarios, login, cambiarContra } from "./handlers/usuarios"

const router = Router()

//endpoints arriendos
router.get("/arriendos", getArriendos)
router.get("/arriendos/:id", getArriendoById)
router.post("/arriendos", crearArriendo)
router.put("/arriendos/:id", editarArriendo)
router.delete("/arriendos/:id", borrarArriendo)

//endpoints usuarios

router.get("/usuarios", getUsuarios)
router.put("/usuarios/:email", editarUsuario)
router.post("/usuarios", crearUsuario)
router.post('/login', login)
router.post('/usuarios/registrar', crearUsuario)
router.get('/usuario', (req, res) => {
  res.json({ message: "Endpoint de usuario" })
})
router.put('/usuarios', cambiarContra)
router.get("/arriendos/terminados", getArriendosTerminados);

export default router
