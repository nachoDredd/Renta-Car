import { useState } from "react";
import axios from "axios";

export default function EditarCuenta() {
  const [passwordAntes, setPasswordAntes] = useState("");
  const [passwordNueva, setPasswordNueva] = useState("");
  const [verContra, setVerContra] = useState(false);


  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    try {
      const email = localStorage.getItem("email");
      const token = localStorage.getItem("token");
      

      const response = await axios.put("http://localhost:3000/api/usuarios",
        { email, passwordAntes, passwordNueva },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      if (response.status === 200) {
        console.log("Cambio de contraseña exitoso");
        alert("Se ha cambiado la contraseña correctamente");
        window.location.reload();
      }
      console.log("Contraseña actualizada correctamente");
    } catch (error: any) {
      console.error("Error al cambiar la contraseña:", error);
      console.log("Error al actualizar la contraseña");
    }
  }
return(
    <>
    <div className="row mt-4 ">
        <h1 className="mb-4">Editar Cuenta</h1>
        <h2 className="mb-4">Cambio de contraseña</h2>
        <form onSubmit={handleSubmit}>
            <div className="mb-3">
            <label htmlFor="passwordA" className="form-label">
              Contraseña actual
            </label>
            <input
              type={verContra ? "text" : "password"}
              value={passwordAntes}
              className="form-control"
              id="passwordA"
              placeholder="Ingrese Contraseña"
              onChange={e => setPasswordAntes(e.target.value)}
              required
            />
          </div>
            <div className="mb-3">
            <label htmlFor="passwordN" className="form-label">
              Contraseña nueva
            </label>
            <input
              type={verContra ? "text" : "password"}
              value={passwordNueva}
              className="form-control"
              id="passwordN"
              placeholder="Ingrese Contraseña"
              onChange={e => setPasswordNueva(e.target.value)}
              required
            />
          </div>
          <div className="form-check mb-3">
            <input
              className="form-check-input"
              type="checkbox"
              id="gridCheck1"
              checked={verContra}
              onChange={(e) => setVerContra(e.target.checked)}
            />
            <label className="form-check-label" htmlFor="gridCheck1">
              Mostrar contraseña
            </label>
          </div>
            <button type="submit" className="btn btn-primary">Guardar Cambios</button>
            
        </form>
    </div>
    </>
    )}