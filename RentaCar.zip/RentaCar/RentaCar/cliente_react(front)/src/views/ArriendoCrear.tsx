import { useState } from "react";
import axios from "axios";
import { useNavigate, Link } from "react-router-dom";

export default function ArriendosCrear() {
  const [nombreCliente, setNombreCliente] = useState("");
  const [patenteVehiculo, setPatenteVehiculo] = useState("");
  const [rutCliente, setRutCliente] = useState("");
  const [tipoVehiculo, setTipoVehiculo] = useState("");
  const [fechaFin, setFechaFin] = useState("");

  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      await axios.post("http://localhost:3000/api/arriendos", {
        nombreCliente,
        rutCliente,
        tipoVehiculo,
        patenteVehiculo,
        fechaInicio: new Date(),
        fechaFin: fechaFin ?? null,
      });

      alert("Arriendo creado con éxito");
      navigate("/Autos");
    } catch (error) {
      console.error("Error al crear el arriendo:", error);
      alert("Error al registrar arriendo.");
    }
  };

  return (
    <div>
      <h2>Registrar Nuevo Arriendo</h2>
      <div className="card">
        <div className="card-body">
          <form onSubmit={handleSubmit}>
            <div className="mb-3">
              <label className="form-label">Nombre del Cliente</label>
              <input
                type="text"
                className="form-control"
                value={nombreCliente}
                onChange={(e) => setNombreCliente(e.target.value)}
                required
              />
            </div>
            <div className="mb-3">
              <label className="form-label">RUT del Cliente</label>
              <input
                type="text"
                className="form-control"
                value={rutCliente}
                onChange={(e) => setRutCliente(e.target.value)}
                required
              />
            </div>
            <div className="mb-3">
              <label className="form-label">Patente del Vehículo</label>
              <input
                type="text"
                className="form-control"
                value={patenteVehiculo}
                onChange={(e) => setPatenteVehiculo(e.target.value)}
                required
              />
            </div>
              <div className="mb-3">
              <label className="form-label">Tipo de Vehículo</label>
              <select
                className="form-select"
                value={tipoVehiculo}
                onChange={(e) => setTipoVehiculo(e.target.value)}
                required
              >
                <option value="TV">Seleccione Tipo de vehiculo</option>
                <option value="SUV">SUV</option>
                <option value="Sedan">Sedan</option>
                <option value="Camioneta">Camioneta</option>
                
              </select>
            </div>

            <div className="mb-3">
              <label className="form-label">Fecha de Fin (opcional)</label>
              <input
                type="date"
                className="form-control"
                value={fechaFin}
                onChange={(e) => setFechaFin(e.target.value)}
              />
            </div>
            <div className="text-end">
              <button type="submit" className="btn btn-primary">
                Registrar Arriendo
              </button>
              <Link to="/arriendos" className="btn btn-secondary ms-2">
                Cancelar
              </Link>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
