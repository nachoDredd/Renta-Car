import { createBrowserRouter } from "react-router-dom";
import Layout from "./layouts/Layout";
import Home from "./views/Home";
import Autos from "./views/Autos";
import AutosCrear from "./views/AutosCrear";
import Login from "./views/Login";
import Registrar from "./views/Registrar";
import AutoDetalle from "./views/AutoDetalle";
import ArriendosCrear from "./views/ArriendoCrear";
import Devolucion from "./views/Devolucion";
import EditarCuenta from "./views/EditarCuenta";



export const router = createBrowserRouter([
    {
        path: '/',
        element:<Layout/>,
        children:[
            {
                index: true,
                element: <Home/>,
            },
            {
                path: 'autos',
                element : <Autos/>
            },
            {
                path: 'autos/crear',
                element : <AutosCrear/>
            },
            {
                path: 'login',
                element : <Login/>
            },
            {
                path: 'registrar',
                element : <Registrar/>
            },
            {
                path: 'autoDetalle',
                element : <AutoDetalle/>
            },
            {
                path: 'arriendos/crear',
                element: <ArriendosCrear/>
            },
            {
                path: 'devolver',
                element: <Devolucion/>
            },
            {
                path: 'editarCuenta',
                element : <EditarCuenta/>
            },
            
        ],
    },
])