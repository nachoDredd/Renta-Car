import { NavLink } from "react-router-dom";
import { useEffect, useState } from "react";
import axios from "axios";

export default function NavBar() {
  const [logeado, setLogeado] = useState(() => !!localStorage.getItem("token"));
  const [email, setEmail] = useState("");
  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("email");
    setLogeado(false);
    setEmail("");
  }
    useEffect(() => {
      const AxiosUsuario = async () => {
        const token = localStorage.getItem("token");
        if (!token) return;

        try {
          const response = await axios.get("http://localhost:3000/api/usuario", {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          });
          setEmail(response.data.email); 
        } catch (error) {
          console.error("Token invÃ¡lido o expirado", error);
          handleLogout();
        }
      }
      AxiosUsuario();
    }, [logeado]);
  return (
    <nav className="navbar navbar-expand-lg bg-body-tertiary">
      <div className="container-fluid">
        <NavLink className="navbar-brand" to="/">
          Automotora
        </NavLink>
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarSupportedContent">
          <ul className="navbar-nav me-auto mb-2 mb-lg-0">
             <li className="nav-item active">
              <NavLink to="/" className="nav-link">
                Inicio
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink to="/arriendos/crear" className="nav-link">
                Arrendar Vehiculo
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink to="/devolver" className="nav-link">
                Devolver Vehiculo
              </NavLink>
            </li>
          </ul>

          {/* Si esta logeado tira este ul */}
          {logeado ? (
            <ul className="nav justify-content-end">
              <div className="dropdown">
                <button
                  className="btn dropdown-toggle"
                  type="button"
                  data-bs-toggle="dropdown"
                  aria-expanded="false"
                >
                  <img
                    src="/Images/persona.jpg"
                    alt="Cuenta"
                    style={{ width: "25px", height: "25px", marginRight: "8px" }}
                  />
                  {email}
                </button>
                <ul className="dropdown-menu dropdown-menu-end">
                  <li>
                    
                    <NavLink className="dropdown-item" to="/editarCuenta">
                      Cuenta
                    </NavLink>
                  </li>
                  <li>
                    <NavLink className="dropdown-item" to="/login" onClick={handleLogout}>
                      Cerrar Sesion
                      <button className="dropdown-item"  >
                        
                      </button>
                    </NavLink>
                  </li>
                </ul>
              </div>
            </ul>
          ) : ( 
            <ul className="nav justify-content-end"> {  /*Si no esta logeado tira esta*/}
              <li className="nav-item active">
                <NavLink to="/registrar" className="nav-link">
                  <img
                    src="/Images/persona.jpg"
                    alt="Registrarse"
                    style={{ width: "20px", height: "20px", marginRight: "8px" }}
                  />
                  
                </NavLink>
              </li>
            </ul>
          )}
        </div>
      </div>
    </nav>
  );
}