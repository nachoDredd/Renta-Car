import { request, Request, Response } from "express";
import Arriendo from "../models/Arriendo";
import { Op } from "sequelize";

export const getArriendos = async(request:Request, response:Response) => {
    const arriendos = await Arriendo.findAll()
    //para retornar en valores ascendentes
    //const arriendos = await Arriendo.findAll({order:[["valores", "ASC", ["valores"]]]})
    response.json({data: arriendos})
}

export const getArriendoById = async(request:Request, response:Response) => {
const { id } = request.params
const arriendoById = await Arriendo.findByPk(id)
response.json({data: arriendoById})
}

export const crearArriendo = async (request:Request, response:Response) => {

    const {nombreCliente, patenteVehiculo, rutCliente, tipoVehiculo, fechaFin} = request.body
    const arriendoNuevo = await Arriendo.create({
        nombreCliente,
        patenteVehiculo,
        rutCliente,
        tipoVehiculo,
        fechaInicio: new Date(),
        fechaFin: fechaFin ?? null,
    })
    response.json({data: arriendoNuevo})
}

export const editarArriendo = async(request:Request, response:Response) => {
    const { id } = request.params
    const editArriendo = await Arriendo.findByPk(id)
    await editArriendo.update(request.body)
    await editArriendo.save()
    response.json({data:editArriendo})
}

export const borrarArriendo = async(request:Request, response:Response) => {
    const { id } = request.params
    const arriendo = await Arriendo.findByPk(id)
    await arriendo.destroy()
    response.json({data: "Arriendo borrado"})
}

export const getArriendosTerminados = async(request:Request, response:Response) =>{
 try {
    const arriendosTerminados = await Arriendo.findAll({
      where: {
        fechaFin: {
          // Sequelize: Not null
          [Op.not]: null
        }
      }
    });

    response.json({ data: arriendosTerminados });
  } catch (error) {
    response.status(500).json({ error: "Error al obtener arriendos terminados" });
  }
};
