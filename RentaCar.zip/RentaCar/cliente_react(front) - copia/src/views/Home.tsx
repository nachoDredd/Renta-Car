import Autos from "./Autos";

export default function Home(){
    return(
        <>
        <div className="container-fluid">  
            <Autos/>
        </div>

        
        </>
    )
}