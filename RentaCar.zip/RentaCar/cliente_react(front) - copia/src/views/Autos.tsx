import auto1 from '/public/Images/r33.png';
import auto2 from '/public/Images/r34.png';
import auto3 from '/public/Images/r35.png';
import auto4 from '/public/Images/sjv.jpg';

const autos = [
  { id: 1, imagen: auto1, descripcion: "Skyline R33" },
  { id: 2, imagen: auto2, descripcion: "Skyline R34" },
  { id: 3, imagen: auto3, descripcion: "Skyline R35" },
  { id: 4, imagen: auto4, descripcion: "Lambito"},
];

export default function Autos(){
    return(
        <>
        {/* Parte de arriba, abajo del navbar */}
        <h2>Autos</h2>
        
        <div className="row" >
            <div className="col-8" >
                <nav aria-label="breadcrumb">
                    <ol className="breadcrumb">
                        <li className="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li className="breadcrumb-item active" aria-current="page">Autos</li>
                    </ol>
                </nav>
            </div>
        </div>

        {/* Cards */}
        <div className="col-9" style={{ margin: "0 auto"}}>
        <div className="d-flex gap-3 flex-wrap">
            {autos.map(auto => (
                <div className="card" style={{ width: "18rem" }} key={auto.id}>
                    <img src={auto.imagen} className="card-img-top" alt="..." />
                    <div className="card-body">
                        <p className="card-text">{auto.descripcion}</p>
                        <a href="/autoDetalle" className="btn btn-primary">Arrendar Vehiculo</a>
                    </div>
                </div>
            ))}
        </div>
        </div>
        </>
    )
}