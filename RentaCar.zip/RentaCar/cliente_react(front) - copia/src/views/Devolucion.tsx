import { useEffect, useState } from "react";
import axios from "axios";

function Devolucion() {
    const [arriendos, setArriendos] = useState([]);
    const [arriendosTerminados, setArriendosTerminados] = useState([]);
    
  const cargarArriendos = async () => {
    const res = await axios.get("http://localhost:3000/api/arriendos");
    const todos = res.data.data;
    const sinDevolver = todos.filter((a: any) => !a.fechaFin);
    const terminados = todos.filter((a: any) => a.fechaFin);
    setArriendos(sinDevolver);
    setArriendosTerminados(terminados);
  };

const devolver = async (idArriendo: number) => {
  try {
    await axios.put(`http://localhost:3000/api/arriendos/${idArriendo}`,{
        fechaFin:new Date(),
    });
       
    alert("Vehículo devuelto");
    cargarArriendos();
  } catch (error) {
    alert("Error al devolver el vehículo");
    console.error(error);
  }
};

const eliminarArriendo = async (id: number) => {
  try {
    await axios.delete(`http://localhost:3000/api/arriendos/${id}`);
    alert("Arriendo eliminado correctamente");

    setArriendosTerminados(prev => prev.filter(a => a !== id));
  } catch (error) {
    console.error("Error al borrar arriendo:", error);
    alert("No se pudo eliminar el arriendo");
  }
};


    const formatearFecha = (fechaISO: string): string => {
  if (!fechaISO) return "";
  const fecha = new Date(fechaISO);
  if (isNaN(fecha.getTime())) return "";

  return fecha.toLocaleString("es-CL", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  });
};

    useEffect(() => {
        cargarArriendos();
    }, []);

    return (
        <div className="row">
            <div className="col-6">
            <h1>Registrar Devoluciones</h1>
            <ul>
                {arriendos.map((arriendo: any) => (
                    <li key={arriendo.idArriendo}>
                        Vehículo: | {arriendo.patenteVehiculo} | arrendado desde: {formatearFecha(arriendo.fechaInicio)}{" "}
                        <button className="btn btn-primary" onClick={() => devolver(arriendo.idArriendo)}>
                            Registrar devolución
                        </button>
                          <button className="btn btn-danger" onClick={() => eliminarArriendo(arriendo.idArriendo)}>
                            Eliminar
                          </button>
                    </li>
                ))}
            </ul>
        </div>
        <div className="col-6">
            <h1>Historial de Devoluciones</h1>
        <ul>
          {arriendosTerminados.map((arriendo: any) => (
            <li key={arriendo.idArriendo}>
              Vehículo arrendado desde: {formatearFecha(arriendo.fechaInicio)} hasta {formatearFecha(arriendo.fechaFin)} patente: | {arriendo.patenteVehiculo} |
              
            </li>
          ))}
        </ul>
        </div>
        </div>
    );
}

export default Devolucion;