import { NavLink } from "react-router-dom";
import { useState } from "react";

export default function NavBar() {
  const [isLoggedIn, setIsLoggedIn] = useState(() => !!localStorage.getItem("token"));

  const handleLogout = () => {
    localStorage.removeItem("token");
    setIsLoggedIn(false);
  };

  return (
    <nav className="navbar navbar-expand-lg bg-body-tertiary">
      <div className="container-fluid">
        <NavLink className="navbar-brand" to="/">
          Automotora
        </NavLink>
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarSupportedContent">
          <ul className="navbar-nav me-auto mb-2 mb-lg-0">
            <li className="nav-item active">
              <NavLink to="/" className="nav-link">
                Inicio
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink to="/Autos" className="nav-link">
                Autos Disponibles
              </NavLink>
            </li>
          </ul>

          {/* Si esta logeado tira este ul */}
          {isLoggedIn ? (
            <ul className="nav justify-content-end">
              <div className="dropdown">
                <button
                  className="btn dropdown-toggle"
                  type="button"
                  data-bs-toggle="dropdown"
                  aria-expanded="false"
                >
                  <img
                    src="/Images/persona.jpg"
                    alt="Cuenta"
                    style={{ width: "25px", height: "25px", marginRight: "8px" }}
                  />
                </button>
                <ul className="dropdown-menu dropdown-menu-end">
                  <li>
                    <NavLink className="dropdown-item" to="/Cuenta">
                      Cuenta
                    </NavLink>
					<NavLink className="dropdown-item" to="/arriendos">
                      Arriendos
                    </NavLink>

                  </li>
                  <li>
                    <button className="dropdown-item" onClick={handleLogout}>
                      Cerrar sesión
                    </button>
                  </li>
                </ul>
              </div>
            </ul>
          ) : ( 
            <ul className="nav justify-content-end"> {  /*Si no esta logeado tira esta*/}
              <li className="nav-item active">
                <NavLink to="/registrar" className="nav-link">
                  <img
                    src="/Images/persona.jpg"
                    alt="Registrarse"
                    style={{ width: "20px", height: "20px", marginRight: "8px" }}
                  />
                  
                </NavLink>
              </li>
            </ul>
          )}
        </div>
      </div>
    </nav>
  );
}
