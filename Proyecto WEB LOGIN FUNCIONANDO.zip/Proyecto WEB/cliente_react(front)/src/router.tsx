import { createBrowserRouter } from "react-router-dom";
import Layout from "./layouts/Layout";
import Home from "./views/Home";
import Autos from "./views/Autos";
import AutosCrear from "./views/AutosCrear";
import Login from "./views/Login";
import Resgitrar from "./views/Registrar";
import AutoDetalle from "./views/AutoDetalle";

export const router = createBrowserRouter([
    {
        path: '/',
        element:<Layout/>,
        children:[
            {
                index: true,
                element: <Home/>,
            },
            {
                path: 'autos',
                element : <Autos/>
            },
            {
                path: 'autos/crear',
                element : <AutosCrear/>
            },
            {
                path: 'login',
                element : <Login/>
            },
            {
                path: 'registrar',
                element : <Resgitrar/>
            },
            {
                path: 'autoDetalle',
                element : <AutoDetalle/>
            },
        ],
    },
])