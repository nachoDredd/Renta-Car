import { Request, Response } from "express"
import Usuario from "../models/Usuario";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";

export const login = async(request:Request, response:Response) => {
   const { email, password } = request.body
   const SECRET = process.env.SECRET_KEY
   try {
       const usuario = await Usuario.findByPk(email)
       if (!usuario ) {
            response.status(401).json({ message: 'Usuario no encontrado' });
            return console.error('Usuario no encontrado:', email);
       }
       console.log("Contraseña enviada:", password);
        console.log("Contraseña en BD:", usuario.password);
       const passwordValido = await bcrypt.compare(password, usuario.password);
        if (!passwordValido) {
            response.status(401).json({ message: 'Contraseña incorrecta' });
            return
        }
        console.log("¿Contraseña válida?", passwordValido);
       const token = jwt.sign({ email: usuario.email }, SECRET, { expiresIn: '1h' });
       response.json({ message: "Inicio de sesión exitoso", token });
   }catch (error) {
       console.error('Error al iniciar sesión:', error);
       response.status(500).json({ error: 'Error interno del servidor' });
   }
}
export const crearUsuario = async(request:Request, response:Response) =>{
    try {
        const { email, password } = request.body;
        console.log("Email:", email);
        console.log("Password original:", password);

        const usuarioNuevo = await Usuario.create({ email, password});
        response.json({data: usuarioNuevo});
    } catch (error) {
        response.status(500).json({ message: "Error al crear usuario", error });
    }
}