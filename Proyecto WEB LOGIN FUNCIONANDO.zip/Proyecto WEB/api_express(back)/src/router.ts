import { Router } from "express"
import { crearUsuario, login } from "./handlers/usuarios"

const router = Router()


//endpoints usuarios
router.post('/login', login)
router.post('/usuarios/registrar', crearUsuario)


export default router
