import { request, Request, Response } from "express";
import Arriendo from "../models/Arriendo";

export const getArriendos = async(request:Request, response:Response) => {
    const arriendos = await Arriendo.findAll()
    //para retornar en valores ascendentes
    //const arriendos = await Arriendo.findAll({order:[["valores", "ASC", ["valores"]]]})
    response.json({data: arriendos})
}

export const getArriendoById = async(request:Request, response:Response) => {
const { id } = request.params
const arriendoById = await Arriendo.findByPk(id)
response.json({data: arriendoById})
}

export const crearArriendo = async (request:Request, response:Response) => {
    console.log(request.body)
    const arriendoNuevo = await Arriendo.create(request.body)
    response.json({data: arriendoNuevo})
}

export const editarArriendo = async(request:Request, response:Response) => {
    const { id } = request.params
    const editArriendo = await Arriendo.findByPk(id)
    await editArriendo.update(request.body)
    await editArriendo.save()
    response.json({data:editArriendo})
}

export const borrarArriendo = async(request:Request, response:Response) => {
    const { id } = request.params
    const arriendo = await Arriendo.findByPk(id)
    await arriendo.destroy()
    response.json({data: "Arriendo borrado"})
}