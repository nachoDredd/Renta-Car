import { Request, Response } from "express";
import Usuario from "../models/Usuario";

export const getUsuarios = async(request:Request, response:Response) => {
    const usuarios = await Usuario.findAll()
    response.json({data: usuarios})
}

export const editarUsuario = async(request:Request, response:Response) => {
    const { email } = request.params
    const editUsuario = await Usuario.findByPk(email)
    await editUsuario.update(request.body)
    await editUsuario.save()
    response.json({data:editUsuario})
}