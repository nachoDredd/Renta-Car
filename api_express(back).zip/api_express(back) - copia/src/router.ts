import { Router } from "express"
import { borrarArriendo, crearArriendo, editarArriendo, getArriendoById, getArriendos } from "./handlers/arriendos"
import { crearUsuario, editarUsuario} from "./handlers/usuarios"
import  LoginUsuario  from "./handlers/usuarios"

const router = Router()

//endpoints arriendos
router.get("/arriendos", getArriendos)
router.get("/arriendos/:id", getArriendoById)
router.post("/arriendos", crearArriendo)
router.put("/arriendos/:id", editarArriendo)
router.delete("/arriendos/:id", borrarArriendo)

//endpoints usuarios
router.put("/usuarios/:email", editarUsuario)

router.post("/usuarios/registrar", crearUsuario)
router.post("/usuarios/login", LoginUsuario);
export default router
