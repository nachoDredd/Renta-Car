import { Column, DataType, Model, Table } from "sequelize-typescript";


@Table({tableName:"usuarios"})
class Usuario extends Model{
    
    
    @Column({ type: DataType.STRING(50), primaryKey: true})
    declare email: string

    @Column({ type: DataType.STRING(60)})
    declare password: string

}
export default Usuario