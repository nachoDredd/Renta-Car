import { Request, Response } from "express";
import Usuario from "../models/Usuario";

export const editarUsuario = async(request:Request, response:Response) => {
    const { email } = request.params
    const editUsuario = await Usuario.findByPk(email)
    await editUsuario.update(request.body)
    await editUsuario.save()
    response.json({data:editUsuario})
}
export const crearUsuario = async(request:Request, response:Response) =>{
    console.log(request.body)
    const usuarioNuevo = await Usuario.create(request.body)
    response.json({data: usuarioNuevo})

}
const LoginUsuario = async(req:Request, res:Response) => {
    try{
        const { email, password} = req.body
        const usuario = await Usuario.findOne({ where : {email} })
        if (!usuario) {
            return res.status(401).json({ message: "Usuario no encontrado" })
        }
        if (usuario.password !== password) {
            return res.status(401).json({ message: "Contraseña incorrecta" })
        }
        return res.status(200).json({ message: "Usuario autenticado correctamente" })
    }catch (error) {
        return res.status(500).json({ message: "Error al autenticar usuario", error })
    }
}
export default LoginUsuario;