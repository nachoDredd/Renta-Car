import { useState } from "react";
import { NavLink } from "react-router-dom";

export default function Login() {

const [verContra, setVerContra] = useState(false)
  return (
    <>
        {/* Imagen de fondo */}
        <div style={{
          width: "100vw",
          height: "100vh",
          backgroundImage: "url(/Images/paisajeE.png)",
          backgroundSize: "cover",
          backgroundPosition: "center",
          padding: "20px",
          borderRadius: "8px",
          position: "relative", 
          overflow: "hidden",
        }}>
        {/* Texto al centro */}
            <div
            style={{
            position: "relative",
            height: "100%",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            }}>
                <form style={{ backgroundColor: "rgba(255, 255, 255, 0.68)", padding: "20px", borderRadius: "8px" }}>
                    <div className="row mb-3">
                        <label htmlFor="inputEmail3" className="col-sm-3 col-form-label">Email</label>
                        <div className="col-sm-9">
                        <input type="email" className="form-control" id="inputEmail3" />
                        </div>
                    </div>
                    <div className="row mb-3">
                        <label htmlFor="inputPassword3" className="col-sm-3 col-form-label">Password</label>
                        <div className="col-sm-9">
                        <input type={verContra ? "text" : "password"} className="form-control" id="inputPassword3" />
                        </div>
                    </div>
                    <div className="row mb-3">
                        <div className="col-sm-10 offset-sm-2">
                        <div className="form-check">
                            <input className="form-check-input" type="checkbox" id="gridCheck1" checked ={verContra} onChange={(e) => setVerContra(e.target.checked)} />
                            <label className="form-check-label" htmlFor="gridCheck1">
                            Mostrar contraseña
                            </label>
                        </div>
                        </div>
                    </div>
                    <div>
                        <NavLink to= "/register" className = "nav-link">
                        No tienes cuenta? <br />Haz click aqui para registrarte
                        </NavLink> 
                    </div>
                    <br />
                    <div className="d-grid gap-2">
                        <button type="submit" className="btn btn-primary">Iniciar sesión</button>
                        
                    </div>
                </form>
            </div>
        </div>
    </>
  );
}
