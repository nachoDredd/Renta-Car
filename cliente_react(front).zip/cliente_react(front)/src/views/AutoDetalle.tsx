export default function AutoDetalle(){
    return(
        <>
        <h1>Nombre del auto</h1>
        <div className="row mt-3">
            <div className="col-4 mt-5">
                <h2>Fotos del auto</h2>
            </div>
            <div className="col-4 mt-5">
                <h2>Fotos del auto</h2>
            </div>
            <div className="col-4 mt-5">
                <h2>Fotos del auto</h2>
            </div>
        </div>
        <div className="row">
            <div className="col-6 mt-5">
                <h2>Descripcion del vehiculo</h2>
            </div>
            <div className="col-6 mt-5">
                <h2>Precio de renta</h2>
                <button type="submit" className="btn btn-primary">Rentar Auto</button>
            </div>
        </div>
        </>
    )
}