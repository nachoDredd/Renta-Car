export default function Home(){
    return(
        <>
        <div className="container-fluid">
            <img src="/Images/imagenes.png" alt="Imagen de rentaCar" width = "50%" height = "50%"/>
            <img src="/Images/imagenes.png" alt="Imagen de rentaCar" width = "50%" height = "50%"/>

        </div>
        
        </>
    )
}